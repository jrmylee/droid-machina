/**
 * Created by jrmylee on 3/7/16.
 */
public class P2_Lee_Jeremy_MinesweeperDriver {
    public static void main(String[] args){
        P2_Lee_Jeremy_MinesweeperController control = new P2_Lee_Jeremy_MinesweeperController(20,20,70);
    }
}
